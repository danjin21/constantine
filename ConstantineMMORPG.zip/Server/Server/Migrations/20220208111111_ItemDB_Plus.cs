﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class ItemDB_Plus : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Dex",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Durability",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Enhance",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Hp",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Int",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Jump",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Luk",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MAtk",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MDef",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "MPnt",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Mp",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Speed",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Str",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "UpgradeSlot",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WAtk",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WDef",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WPnt",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Dex",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Durability",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Enhance",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Hp",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Int",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Jump",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Luk",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "MAtk",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "MDef",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "MPnt",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Mp",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Speed",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "Str",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "UpgradeSlot",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "WAtk",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "WDef",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "WPnt",
                table: "Item");
        }
    }
}
