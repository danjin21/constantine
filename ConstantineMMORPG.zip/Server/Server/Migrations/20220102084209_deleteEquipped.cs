﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class deleteEquipped : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Helmet",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "LeftHand",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "Pants",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "RightHand",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "Shirts",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "Shoes",
                table: "Player");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Helmet",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "LeftHand",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Pants",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "RightHand",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Shirts",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Shoes",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
