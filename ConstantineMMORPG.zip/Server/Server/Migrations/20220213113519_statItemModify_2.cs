﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class statItemModify_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "atkSpeed",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "mAtk",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "mDef",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "mPnt",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "wAtk",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "wDef",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "wPnt",
                table: "Player");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "atkSpeed",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "mAtk",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "mDef",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "mPnt",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "wAtk",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "wDef",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "wPnt",
                table: "Player",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
