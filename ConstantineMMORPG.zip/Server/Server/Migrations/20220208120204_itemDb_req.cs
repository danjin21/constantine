﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class itemDb_req : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ReqDex",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ReqInt",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ReqLev",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ReqLuk",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ReqPop",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ReqStr",
                table: "Item",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ReqDex",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "ReqInt",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "ReqLev",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "ReqLuk",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "ReqPop",
                table: "Item");

            migrationBuilder.DropColumn(
                name: "ReqStr",
                table: "Item");
        }
    }
}
