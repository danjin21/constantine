﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class dan : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
      


            migrationBuilder.CreateTable(
                name: "KeySetting",
                columns: table => new
                {
                    KeySettingDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OwnerDbId = table.Column<int>(type: "int", nullable: true),
                    Delete = table.Column<int>(type: "int", nullable: false),
                    End = table.Column<int>(type: "int", nullable: false),
                    PageDown = table.Column<int>(type: "int", nullable: false),
                    Insert = table.Column<int>(type: "int", nullable: false),
                    Home = table.Column<int>(type: "int", nullable: false),
                    PageUp = table.Column<int>(type: "int", nullable: false),
                    Shift = table.Column<int>(type: "int", nullable: false),
                    Control = table.Column<int>(type: "int", nullable: false),
                    SpaceBar = table.Column<int>(type: "int", nullable: false),
                    Number1 = table.Column<int>(type: "int", nullable: false),
                    Number2 = table.Column<int>(type: "int", nullable: false),
                    Number3 = table.Column<int>(type: "int", nullable: false),
                    Number4 = table.Column<int>(type: "int", nullable: false),
                    Number5 = table.Column<int>(type: "int", nullable: false),
                    Number6 = table.Column<int>(type: "int", nullable: false),
                    Number7 = table.Column<int>(type: "int", nullable: false),
                    Number8 = table.Column<int>(type: "int", nullable: false),
                    Number9 = table.Column<int>(type: "int", nullable: false),
                    Number0 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_KeySetting", x => x.KeySettingDbId);
                    table.ForeignKey(
                        name: "FK_KeySetting_Player_OwnerDbId",
                        column: x => x.OwnerDbId,
                        principalTable: "Player",
                        principalColumn: "PlayerDbId",
                        onDelete: ReferentialAction.Restrict);
                });

         

            migrationBuilder.CreateIndex(
                name: "IX_KeySetting_OwnerDbId",
                table: "KeySetting",
                column: "OwnerDbId");

          
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {


            migrationBuilder.DropTable(
                name: "KeySetting");

        }
    }
}
