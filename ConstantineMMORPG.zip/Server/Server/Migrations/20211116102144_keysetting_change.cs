﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class keysetting_change : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Control",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Delete",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "End",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Home",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Insert",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number0",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number1",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number2",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number3",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number4",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number5",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number6",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number7",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number8",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "Number9",
                table: "KeySetting");

            migrationBuilder.DropColumn(
                name: "PageDown",
                table: "KeySetting");

            migrationBuilder.RenameColumn(
                name: "SpaceBar",
                table: "KeySetting",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "Shift",
                table: "KeySetting",
                newName: "key");

            migrationBuilder.RenameColumn(
                name: "PageUp",
                table: "KeySetting",
                newName: "action");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "type",
                table: "KeySetting",
                newName: "SpaceBar");

            migrationBuilder.RenameColumn(
                name: "key",
                table: "KeySetting",
                newName: "Shift");

            migrationBuilder.RenameColumn(
                name: "action",
                table: "KeySetting",
                newName: "PageUp");

            migrationBuilder.AddColumn<int>(
                name: "Control",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Delete",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "End",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Home",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Insert",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number0",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number1",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number2",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number3",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number4",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number5",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number6",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number7",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number8",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Number9",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "PageDown",
                table: "KeySetting",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
