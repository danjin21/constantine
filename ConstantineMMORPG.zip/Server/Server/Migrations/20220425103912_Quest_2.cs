﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Server.Migrations
{
    public partial class Quest_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "QuestStatus",
                columns: table => new
                {
                    QuestDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestDbTemplateId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    OwnerDbId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestStatus", x => x.QuestDbId);
                    table.ForeignKey(
                        name: "FK_QuestStatus_Player_OwnerDbId",
                        column: x => x.OwnerDbId,
                        principalTable: "Player",
                        principalColumn: "PlayerDbId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "QuestMobCount",
                columns: table => new
                {
                    QuestMobCountDbId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MobId = table.Column<int>(type: "int", nullable: false),
                    Count = table.Column<int>(type: "int", nullable: false),
                    QuestDbId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestMobCount", x => x.QuestMobCountDbId);
                    table.ForeignKey(
                        name: "FK_QuestMobCount_QuestStatus_QuestDbId",
                        column: x => x.QuestDbId,
                        principalTable: "QuestStatus",
                        principalColumn: "QuestDbId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_QuestMobCount_QuestDbId",
                table: "QuestMobCount",
                column: "QuestDbId");

            migrationBuilder.CreateIndex(
                name: "IX_QuestStatus_OwnerDbId",
                table: "QuestStatus",
                column: "OwnerDbId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "QuestMobCount");

            migrationBuilder.DropTable(
                name: "QuestStatus");
        }
    }
}
