﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CreateAccountPacketReq
{
    public string AccountName;
    public string Password;
}

public class CreateAccountPacketRes
{
    public bool CreateOk;
    public string Info;
}



public class LoginAccountPacketReq
{
    public string AccountName;
    public string Password;
}



public class ServerInfo
{
    public string Name;
    public string IpAddress;
    public int Port;
    public int BusyScore;

}


public class LoginAccountPacketRes
{
    public bool LoginOk;
    public int AccountId;
    public int Token;
    public string AccountName;
    public List<ServerInfo> ServerList = new List<ServerInfo>();
    public string Info;
}


public class LogoutAccountPacketReq
{
    public string AccountName;
    public string Password;
}


public class LogoutAccountPacketRes
{
    public bool LogoutOk { get; set; }
}




//public class WebPacket
//{
//    public static void SendCreateAccount(string account, string password)
//    {
//        CreateAccountPacketReq packet = new CreateAccountPacketReq()
//        {
//            AccountName = account,
//            Password = password
//        };

//        Managers.Web.SendPostRequest<CreateAccountPacketRes>("account/create", packet, (res) =>
//        {
//            // 응답이오면 처리하는 부분
//            Debug.Log("result = "+ res.CreateOk);
//        });
//    }


//    public static void SendLoginAccount(string account, string password)
//    {
//        LoginAccountPacketReq packet = new LoginAccountPacketReq()
//        {
//            AccountName = account,
//            Password = password
//        };

//        Managers.Web.SendPostRequest<LoginAccountPacketRes>("account/login", packet, (res) =>
//        {
//            // 응답이오면 처리하는 부분
//            Debug.Log("result = " + res.LoginOk);
//        });
//    }

//}


